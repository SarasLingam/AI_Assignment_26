
namespace HealthcareRefitFramework.Utilities
{
    public static class TestDataHelper
    {
        public static string GeneratePatientName()
        {
            return "Patient_" + System.Guid.NewGuid();
        }
    }
}
