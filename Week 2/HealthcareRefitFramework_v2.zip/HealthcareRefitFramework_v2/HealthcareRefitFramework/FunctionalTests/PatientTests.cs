
using Xunit;
using FluentAssertions;
using HealthcareRefitFramework.Services;
using HealthcareRefitFramework.Models.Request;
using System.Threading.Tasks;

namespace HealthcareRefitFramework.FunctionalTests
{
    public class PatientTests
    {
        [Fact]
        public async Task CreatePatient_ShouldReturnSuccess()
        {
            var api = ApiClientFactory.GetPatientApi();

            var request = new CreatePatientRequest
            {
                FirstName = "John",
                LastName = "David",
                Age = 30,
                Gender = "Male"
            };

            var response = await api.CreatePatient(request);

            response.IsSuccessStatusCode.Should().BeTrue();
            response.Content.Status.Should().Be("SUCCESS");
        }
    }
}
