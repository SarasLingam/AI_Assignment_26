
# Healthcare API Automation Framework - C# Refit + xUnit

## Overview
This framework is designed for enterprise healthcare API automation using:
- C#
- Refit
- xUnit
- Allure Reporting
- RestSharp
- FluentAssertions

---

## Framework Architecture

```
HealthcareRefitFramework
├── Config
├── Core
├── Endpoints
├── FunctionalTests
├── Models
│   ├── Request
│   └── Response
├── Services
├── Utilities
├── Reports
└── README.md
```

---

## Step-by-Step Working

### Step 1
API endpoint is defined inside `Endpoints/PatientEndpoints.cs`

### Step 2
Refit interface calls API methods

### Step 3
Request models are sent using DTO classes

### Step 4
Response models deserialize API response

### Step 5
Functional tests validate:
- Status code
- Response body
- Business validations

### Step 6
Allure generates execution reports

---

## Execute Test Cases

### Install Dependencies

```bash
dotnet restore
```

### Execute Tests

```bash
dotnet test
```

### Generate Allure Report

```bash
allure serve allure-results
```

---

## Packages Used

- Refit
- xUnit
- FluentAssertions
- Newtonsoft.Json
- Allure.Xunit

---

## Healthcare Sample Covered

- Create Patient API
- Get Patient API
- Request Models
- Response Models
- Functional Validations
