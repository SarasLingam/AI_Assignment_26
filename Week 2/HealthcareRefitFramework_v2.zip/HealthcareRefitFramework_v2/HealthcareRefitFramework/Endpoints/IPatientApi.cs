
using Refit;
using System.Threading.Tasks;
using HealthcareRefitFramework.Models.Request;
using HealthcareRefitFramework.Models.Response;

namespace HealthcareRefitFramework.Endpoints
{
    public interface IPatientApi
    {
        [Post("/patients")]
        Task<ApiResponse<CreatePatientResponse>> CreatePatient(
            [Body] CreatePatientRequest request);

        [Get("/patients/{id}")]
        Task<ApiResponse<GetPatientResponse>> GetPatient(int id);
    }
}
