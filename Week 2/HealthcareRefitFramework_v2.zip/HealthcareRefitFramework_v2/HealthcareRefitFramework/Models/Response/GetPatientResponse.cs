
namespace HealthcareRefitFramework.Models.Response
{
    public class GetPatientResponse
    {
        public int PatientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
    }
}
