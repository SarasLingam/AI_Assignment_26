
namespace HealthcareRefitFramework.Models.Response
{
    public class CreatePatientResponse
    {
        public int PatientId { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
