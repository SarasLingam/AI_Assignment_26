
using Refit;
using HealthcareRefitFramework.Endpoints;

namespace HealthcareRefitFramework.Services
{
    public static class ApiClientFactory
    {
        public static IPatientApi GetPatientApi()
        {
            return RestService.For<IPatientApi>(
                "https://healthcare-api-demo.com");
        }
    }
}
